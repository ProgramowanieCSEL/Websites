import Header from '../components/header';
import Main from '../components/main';
import Footer from '../components/footer';
import { useState } from 'react';
function Index() {
    const [navList,setNavList] = useState([
      "Strona główna","Zamówienia","Blog","Gatunki kawy"
    ]);
    const [itemList, setItemList] = useState([
      "Arabica", "Robusta", "bezkofeinowa", "zielona"
    ])
    return (
      <>
        <Header nav={navList}></Header>
        <Main list={itemList}></Main>
        <Footer></Footer>
      </>
    );
  }
  
  export default Index;