import Header from '../../components/header';
import Main from '../../components/main';
import Footer from '../../components/footer';
function Order() {
    const [navList,setNavList] = useState([
      "Strona główna","Zamówienia","Blog","Gatunki kawy"
    ]);
    const [itemList, setItemList] = useState([
      "Arabica", "Robusta", "bezkofeinowa", "zielona"
    ])
    return (
      <>
        <Header nav={navList}></Header>
        <main>Strona w trakcie budowy</main>
        <Footer></Footer>
      </>
    );
  }
  
  export default Order;