import Nav from "./navigation";
import headerLogo from '../images/logo.png';

function Header({nav}) {
    return (
      <header>
        <Nav nav={nav}></Nav>
        <img src={headerLogo} alt="logo"></img>
      </header>
    )
  }

  export default Header;