import MainSection from "./mainSection";
import LogoContainer from "./logoContainer";
import OfferSection from "./offerSection"
;
function Main({ list }) {
    return (
      <main>
        <div style={{ backgroundColor: "saddlebrown", height: "150px", display: "grid", alignItems: "center", letterSpacing: "20px", padding: "30px" }}><h1>Sklep z kawą</h1></div>
        <MainSection list={list}>
          <LogoContainer></LogoContainer>
          <OfferSection list={list}></OfferSection>
        </MainSection>
      </main>
    )
  }
export default Main;