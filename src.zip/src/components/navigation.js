function Nav({nav}) {
    return (
      <nav>
        {nav.map(item => (
          <p>{item}</p>
        ))}
      </nav>
    )
  }

  export default Nav;