function Footer() {
    return (
      <footer style={{display:"grid",backgroundColor:"saddlebrown"}}>
        <p style = {{fontWeight:"bold",textAlign:"center"}}>Stronę przygotował:Mateusz Mikołajczyk</p>
      </footer>
    )
  }

export default Footer;