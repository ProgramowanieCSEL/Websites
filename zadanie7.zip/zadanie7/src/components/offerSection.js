function OfferSection({ list }) {
    return (
      <div>
        <h3>Oferta</h3>
        <ul>
          {list.map((item, index) => (
            index === 2 ? <li id="unavailable" key={index}>{item}</li> : <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    )
  }
  export default OfferSection;