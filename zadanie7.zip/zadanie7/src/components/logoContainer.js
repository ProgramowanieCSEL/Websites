import storeLogo from '../images/1c.png';

function LogoContainer() {
    return (
      <div className='logoContainer'><img src={storeLogo} alt="filiżanka kawy?"></img></div>
    );
  }
  
export default LogoContainer;