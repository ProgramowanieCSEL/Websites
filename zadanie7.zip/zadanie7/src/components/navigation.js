function Nav({nav,handleclick,content,mainpageredirect}) {
    return (
      <nav>
        {nav.map((item,index) => (
          index === 1 ? <p key={index} onClick={handleclick}>{item}</p> : (index === 0 ? <p key={index} onClick={mainpageredirect}>{item}</p> : <p key={index}>{item}</p>)
        ))}
      </nav>
    )
  }

  export default Nav;