function Footer() {
    return (
      <footer>
        <p>Stronę przygotował:Mateusz Mikołajczyk</p>
      </footer>
    )
  }

export default Footer;