
function ComputeSection() {
    return (
        <div id="calculate-section">
            <div>
            <label>Podaj numery kawy: </label>
            <input type="number" id="coffee-id"></input>
            </div>
            <br />
            <div>
            <label>Podaj wagę w dekagramach</label>
            <input type="number" id="coffee-weight"></input>
            <button onClick={calculatePrice}>Zamów</button>
            <p id="price-paragraph"></p>
            </div>
           
        </div>
    )
    function calculatePrice() {
        let availableIds = [1,2,4];
        let prices=[5,7,6];
        let status = 0;
        let id = document.querySelector("#coffee-id").value;
        let weight = document.querySelector("#coffee-weight").value;
        let price = document.querySelector("#price-paragraph");
        for (let i = 0;i<3;i++) {
            if (id!== `${availableIds[i]}`) {
                status++;
            }
            if (status === 3 || weight.length === 0 || id.length === 0) {
                price.innerHTML = "Cena wynosi 0zł";
            }
            else  {
                price.innerHTML = `Cena wynosi ${parseInt(prices[i]) * parseInt(weight)}zł`;
            }
           
        } 
    }
}

export default ComputeSection;