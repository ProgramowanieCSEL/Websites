import Nav from "./navigation";
import headerLogo from '../images/logo.png';

function Header({children}) {
    return (
      <header>
        {children}
        <img src={headerLogo} alt="logo"></img>
      </header>
    )
  }

  export default Header;