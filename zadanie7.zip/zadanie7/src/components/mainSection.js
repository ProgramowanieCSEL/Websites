import LogoContainer from "./logoContainer";
import OfferSection from "./offerSection";
function MainSection({ list }) {
    return (
      <section id="offers-section">
        <LogoContainer></LogoContainer>
        <OfferSection list={list}></OfferSection>
      </section>
    )
  }
  export default MainSection;