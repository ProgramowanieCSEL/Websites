import Header from '../components/header';
import Main from '../components/main';
import Footer from '../components/footer';
import ComputeSection from '../components/calculateSection';
import Nav from '../components/navigation';
import { useState } from 'react';
function Index() {
  const [navList, setNavList] = useState([
    "Strona główna", "Zamówienia", "Blog", "Gatunki kawy"
  ]);
  const [itemList, setItemList] = useState([
    "Arabica", "Robusta", "bezkofeinowa", "zielona"
  ])
  const [content, setContent] = useState(0);
  function handleclick() {
    content === 0 ? setContent(1) : setContent(0);
  }
  function mainPageRedirect() {
    setContent(0);
  }
  if (content === 0) {
    return [
      <Header><Nav nav={navList} handleclick={handleclick} content={content} mainpageredirect={mainPageRedirect}></Nav></Header>,
      <Main list={itemList}></Main>,
      <Footer></Footer>
    ]
  }
  else {
    return [
      <Header><Nav nav={navList} handleclick={handleclick} content={content} mainpageredirect={mainPageRedirect}></Nav></Header>,
      <ComputeSection></ComputeSection>,
      <Footer></Footer>
    ]
  }
}

export default Index;