import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import Index from './pages';
function App() {

  return (
    <>
      <Index></Index>
    </>
  );
}

export default App;
